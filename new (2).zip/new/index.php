<?php
    session_start();
    require "pages/includes/dbh.inc.php";
    require "pages/indexHeader.php";
    require "pages/content.php";
    require "pages/footer.php";
?>